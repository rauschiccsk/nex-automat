# Zdieľané pravidlá BOZP

## Bezpečnosť a ochrana zdravia pri práci

Tieto pravidlá platia pre všetkých zamestnancov bez ohľadu na spoločnosť.

## Základné pravidlá

1. Nosenie ochranných pomôcok v sklade
2. Dodržiavanie požiarnych predpisov
3. Hlásenie pracovných úrazov do 24 hodín
