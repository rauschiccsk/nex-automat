# ICC Interné Procesy

## Firemná kultúra ICC

ICC Komárno je softvérová spoločnosť založená v roku 1990.
Špecializujeme sa na ERP systémy pre stredné a veľké podniky.

## Pracovná doba

- Pondelok - Piatok: 8:00 - 16:30
- Flexibilný začiatok: 7:00 - 9:00
- Home office: max 2 dni týždenne

## Kontakty

- IT podpora: it@icc.sk
- HR oddelenie: hr@icc.sk
