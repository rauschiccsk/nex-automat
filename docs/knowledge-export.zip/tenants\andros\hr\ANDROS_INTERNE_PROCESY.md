# ANDROS Interné Procesy

## O spoločnosti ANDROS

ANDROS s.r.o. je distribučná spoločnosť so sídlom v Bratislave.
Zameriavame sa na distribúciu potravín a nápojov.

## Pracovná doba

- Pondelok - Piatok: 7:00 - 15:30
- Sklad: 6:00 - 22:00 (zmeny)
- Víkendy: podľa potreby

## Kontakty

- Sklad: sklad@andros.sk
- Objednávky: objednavky@andros.sk
