# Session Title

**Dátum:** SESSION_DATE
**Status:** ✅ DONE / 🔄 IN PROGRESS

---

## Dokončené úlohy

- Task 1
- Task 2

## Aktuálny problém (ak existuje)

Popis problému...

## Next Steps

1. Step 1
2. Step 2

## Dôležité príkazy

```powershell
# príklad
```
