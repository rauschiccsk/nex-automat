# Shared Knowledge Base

Documents available to **all tenants**.

## Current Content

- `strategic/` - Product strategy documents (NEX Brain, etc.)
- `processes/` - Common business processes
- `reference/` - Reference documentation

## Indexing

Documents here have no tenant tag and appear in all tenant searches.

